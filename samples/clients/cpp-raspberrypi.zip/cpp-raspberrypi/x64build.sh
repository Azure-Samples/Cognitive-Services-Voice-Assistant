#!/bin/bash
clear
echo "Building Raspberry Pi x64 sample"
g++ -std=c++14 \
-L./lib/x64 \
-I./include/cxx_api \
-I./include/c_api \
-I./include/tinyalsa \
-I./include \
-lpthread \
-l:libtinyalsa.so.1.0.0 \
-lpma \
-lMicrosoft.CognitiveServices.Speech.core \
main.cpp  AudioPlayer2.cpp -o sample.exe