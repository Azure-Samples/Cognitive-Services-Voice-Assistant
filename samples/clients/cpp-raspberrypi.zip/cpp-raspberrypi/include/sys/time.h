#pragma once

#ifndef _TIMES_H

#include "sys/times.h"

#endif