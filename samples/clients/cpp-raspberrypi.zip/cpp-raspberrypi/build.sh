#!/bin/bash
clear
echo "Building Raspberry Pi sample"
arm-linux-gnueabihf-g++ -std=c++14 \
-L./lib/arm32 \
-I./include/cxx_api \
-I./include/c_api \
-I./include \
-lpthread \
-lMicrosoft.CognitiveServices.Speech.core \
main.cpp -o sample.exe

