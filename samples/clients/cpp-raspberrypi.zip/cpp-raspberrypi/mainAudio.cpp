#include <iostream>
#include <string> 
#include <alsa/asoundlib.h>
#include "speechapi_cxx.h"
#include "json.hpp"

using namespace std; 
using namespace Microsoft::CognitiveServices::Speech::Dialog;
using namespace Microsoft::CognitiveServices::Speech;
using namespace Microsoft::CognitiveServices::Speech::Audio;

void log()
{
    cout << endl;
}

template<typename T, typename... Args>
void log(T v, Args... args)
{
    cout << v << flush;
    log(args...);
}

template<typename T, typename... Args>
void log_t(T v, Args... args)
{
    cout << chrono::duration_cast<chrono::milliseconds>(chrono::system_clock::now().time_since_epoch()).count() % 10000000 << "  ";
    log(v, args...);
}

int main () 
{
	string s;
    
	std::shared_ptr<DialogServiceConfig> config = BotFrameworkConfig::FromSubscription("c29bbe9dad89459dbaa31e47caa11f60", "westus");
	
    std::shared_ptr<DialogServiceConnector> dialogServiceConnector = DialogServiceConnector::FromConfig(config);
    
//    AudioPlayer2 player;
    
	dialogServiceConnector->SessionStarted += [&](const SessionEventArgs& e) {
        printf("SESSION STARTED: %s ...\n", e.SessionId.c_str());
    };

    dialogServiceConnector->SessionStopped += [&](const SessionEventArgs& e) {
        printf("SESSION STOPPED: %s ...\n", e.SessionId.c_str());
        printf("Press ENTER to acknowledge...\n");
    };

    dialogServiceConnector->Recognizing += [&](const SpeechRecognitionEventArgs& e) {
        printf("INTERMEDIATE: %s ...\n", e.Result->Text.c_str());
    };

    dialogServiceConnector->Recognized += [&](const SpeechRecognitionEventArgs& e) {
        printf("FINAL RESULT: '%s'\n", e.Result->Text.c_str());
    };

    dialogServiceConnector->Canceled += [&](const SpeechRecognitionCanceledEventArgs& e) {

        printf("CANCELED: Reason=%d\n", (int)e.Reason);
        if (e.Reason == CancellationReason::Error)
        {
            printf("CANCELED: ErrorDetails=%s\n", e.ErrorDetails.c_str());
            printf("CANCELED: Did you update the subscription info?\n");
        }
    };
	
	dialogServiceConnector->ActivityReceived += [&](const ActivityReceivedEventArgs& event) {
        auto activity = nlohmann::json::parse(event.GetActivity());

            log_t("ActivityReceived, type=", activity.value("type", ""), ", audio=", event.HasAudio() ? "true" : "false");

            if (activity.contains("text"))
            {
                log_t("activity[\"text\"]: ", activity["text"].get<string>());
            }

            auto continue_multiturn = activity.value<string>("inputHint", "") == "expectingInput";

            if (event.HasAudio())
            {
                log_t("Activity has audio, playing synchronously");

                log_t("Resetting audio...");

		
                //auto closeResult = player.Close();
                //auto openResult = player.Open();
                //cout << "Attempted reset complete: "
                   // << closeResult
                    //<< " "
                    //<< openResult
                    //<< endl << flush;

                // TODO: AEC + Barge-in
                // For now: no KWS during playback
                //dialogServiceConnector->StopKeywordRecognitionAsync();

                auto audio = event.GetAudio();
		snd_pcm_t      *playback_handle;

		const char           *snd_device_out = "plughw:0,0";
		int err;

		if ((err = snd_pcm_open(&playback_handle, snd_device_out, SND_PCM_STREAM_PLAYBACK, 0)) < 0) {
		fprintf(stderr, "cannot open output audio device %s: %s\n", snd_device_out, snd_strerror(err));
		exit(1);
		}

                const unsigned int buffer_size{ 8192 };
                uint8_t data[buffer_size];
                uint32_t bytes_read = 0;
                uint32_t total_bytes_read = 0;
                do
                {
                    bytes_read = audio->Read(data, buffer_size);
                    //auto play_result = player.Play(data, bytes_read);
                    total_bytes_read += bytes_read;

                    //cout << "Read " << bytes_read << " bytes. Play result: " << play_result << endl;

                    if (total_bytes_read == 0)
                    {
                        log_t("First read of activity audio complete");
                    }
                    else
                    {
                        cout << "." << flush;
                    }

                    //if (play_result)
                    //{
                    //    log_t("Play didn't return expected: ", play_result);
                    //    break;
                    //}
                } while (bytes_read > 0);

                cout << endl;
                log_t("Playback of ", total_bytes_read, " bytes complete.");

                if (!continue_multiturn)
                {
                    // DeviceStatusIndicators::SetStatus(DeviceStatus::Idle);
                }
            }

            if (continue_multiturn)
            {
                log_t("Activity requested a continuation (ExpectingInput) -- listening again");
                // DeviceStatusIndicators::SetStatus(DeviceStatus::Listening);
                dialogServiceConnector->ListenOnceAsync().wait();
            }
            else
            {
                // startKwsIfApplicable();
            }
        };
	
	dialogServiceConnector->ListenOnceAsync();
	
	
	cout << "Now listening ...\nPress x and return to exit";
	cin  >> s;
	
	while(s != "x"){
		cin >> s;
	}
	
	return 0;
}
